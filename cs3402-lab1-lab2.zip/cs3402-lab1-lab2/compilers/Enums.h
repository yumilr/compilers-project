#pragma once

enum Categoria { IDENTIFICADOR = 255, RELOP, ASSIGN, NUMERO, ERROR, END };
